-- 7MF Store https://discord.gg/3gN6ntYuke
-- ما احلل اي شخص ينشر السكربت بدون حقوقي

local QBCore = exports['qb-core']:GetCoreObject()


local interfaceOpen = false
local cursorActive  = false
local openRequested = false
local playerData = {}
local lastPlayerCount = 0
local isLoaded = false


CreateThread(function()
    Wait(500)


    local immediatePlayerData = QBCore.Functions.GetPlayerData()
    if immediatePlayerData and immediatePlayerData.job then
        isLoaded = true
        playerData = immediatePlayerData
    else

    end
end)


local function SetupVoiceDetection()
    if not Config.Radio.enabled then return end



    if Config.Radio.scriptName == 'pma-voice' then
        RegisterNetEvent('pma-voice:radioActive')
        AddEventHandler('pma-voice:radioActive', function(talking)
            TriggerServerEvent('7MF-hub:server:playerTalking', talking)
        end)
    elseif Config.Radio.scriptName == 'pma-voice' then
        exports['pma-voice']:addPlayerToCall('7MF-hub', function(talking)
            TriggerServerEvent('7MF-hub:server:playerTalking', talking)
        end)
    elseif Config.Radio.scriptName == 'saltychat' then
        RegisterNetEvent('SaltyChat_TalkStateChanged')
        AddEventHandler('SaltyChat_TalkStateChanged', function(talking)
            TriggerServerEvent('7MF-hub:server:playerTalking', talking)
        end)
    elseif Config.Radio.scriptName == 'mumble-voip' then
        RegisterNetEvent('mumble:SetVoiceData')
        AddEventHandler('mumble:SetVoiceData', function(data)
            if data.talking ~= nil then
                TriggerServerEvent('7MF-hub:server:playerTalking', data.talking)
            end
        end)
    end
end


local function HasPermission()
    local playerData = QBCore.Functions.GetPlayerData()
    if not playerData or not playerData.job then
        return false
    end

    for _, job in pairs(Config.EmergencyJobs) do
        if playerData.job.name == job then
            return true
        end
    end


    return false
end


local function OpenInterface()
    if not HasPermission() then
        QBCore.Functions.Notify('You do not have permission to use this interface', 'error')
        return
    end
    if not isLoaded then
        QBCore.Functions.Notify('Please wait, system is loading...', 'error')
        return
    end
    interfaceOpen = true
    cursorActive  = true
    openRequested = true 
    SetNuiFocus(true, true)
    TriggerServerEvent('7MF-hub:server:requestData')
end


local function ReleaseCursor()
    if not cursorActive then return end
    cursorActive = false
    SetNuiFocus(false, false)
end

local function CloseInterface()
    interfaceOpen = false
    cursorActive  = false
    openRequested = false
    SetNuiFocus(false, false)
    SendNUIMessage({
        type = 'police_interface',
        action = 'hide'
    })
end


local function AutoUpdateInterface()
    if HasPermission() and isLoaded then
        TriggerServerEvent('7MF-hub:server:requestData')
    end
end


RegisterKeyMapping('ph', 'Toggle Police Interface', 'keyboard', Config.Interface.toggleKey)


RegisterCommand('ph', function()
    local playerData = QBCore.Functions.GetPlayerData()

    if not playerData then
        return
    end

    if not isLoaded then
        QBCore.Functions.Notify('System is still loading, please wait...', 'error')
        return
    end

    if HasPermission() then
        if interfaceOpen then
            CloseInterface()
        else
            OpenInterface()
        end
    else
        QBCore.Functions.Notify('You must be an emergency services employee to use this interface', 'error')
    end
end, false)


RegisterNetEvent('QBCore:Client:OnPlayerLoaded', function()
    isLoaded = true


    SetTimeout(1000, function()
        playerData = QBCore.Functions.GetPlayerData()

        if playerData and playerData.job then
            SetupVoiceDetection()


            CloseInterface()


            if HasPermission() then
                SetTimeout(1000, function()
                    AutoUpdateInterface()
                end)
            end
        else
            SetTimeout(2000, function()
                playerData = QBCore.Functions.GetPlayerData()
                if playerData and playerData.job then
                    if HasPermission() then
                        AutoUpdateInterface()
                    end
                end
            end)
        end
    end)
end)


RegisterNetEvent('QBCore:Client:OnJobUpdate', function(JobInfo)
    if not JobInfo then return end

    local oldJob = playerData.job and playerData.job.name or 'none'
    local oldOnDuty = playerData.job and playerData.job.onduty or false


    playerData.job = JobInfo
    local newJob = JobInfo.name or 'none'
    local newOnDuty = JobInfo.onduty or false




    local wasEmergency = false
    local isEmergency = false

    for _, job in pairs(Config.EmergencyJobs) do
        if oldJob == job then wasEmergency = true end
        if newJob == job then isEmergency = true end
    end


    if wasEmergency and not isEmergency and interfaceOpen then
        CloseInterface()
    end


    if wasEmergency or isEmergency or oldOnDuty ~= newOnDuty then
        SetTimeout(1500, function()
            if isLoaded then
                AutoUpdateInterface()
            end
        end)
    end
end)


RegisterNetEvent('QBCore:Client:SetDuty', function(onDuty)
    if playerData.job then
        playerData.job.onduty = onDuty


        SetTimeout(1000, function()
            if isLoaded then
                AutoUpdateInterface()
            end
        end)
    end
end)


RegisterNetEvent('7MF-hub:client:receiveData', function(data)
    if not data then return end
    if not interfaceOpen then return end

    local newPlayerCount = 0
    if data.Employees and type(data.Employees) == 'table' then
        for _ in pairs(data.Employees) do
            newPlayerCount = newPlayerCount + 1
        end
    end

    local action = openRequested and 'show' or 'update'
    openRequested = false

    SendNUIMessage({
        type   = 'police_interface',
        action = action,
        data   = data
    })

    lastPlayerCount = newPlayerCount
end)


RegisterNetEvent('7MF-hub:client:updateData', function(data)
    if not data then return end

    local newPlayerCount = 0
    if data.employees then
        if type(data.employees) == 'table' then
            for _, _ in pairs(data.employees) do
                newPlayerCount = newPlayerCount + 1
            end
        end
    end

    SendNUIMessage({
        type = 'police_interface',
        action = 'update',
        data = data
    })

    lastPlayerCount = newPlayerCount


    if interfaceOpen then
        SendNUIMessage({
            type = 'police_interface',
            action = 'forceUpdate',
            data = data
        })
    end
end)


RegisterNetEvent('7MF-hub:client:updateTalking', function(playerId, talking)
    SendNUIMessage({
        type = 'police_interface',
        action = 'updateTalking',
        data = {
            playerId = playerId,
            talking = talking
        }
    })
end)


RegisterNetEvent('7MF-hub:client:playerJoined', function(playerData)
    SetTimeout(2000, function()
        if isLoaded then
            AutoUpdateInterface()
        end
    end)
end)

RegisterNetEvent('7MF-hub:client:playerLeft', function(playerId)
    SetTimeout(1000, function()
        if isLoaded then
            AutoUpdateInterface()
        end
    end)
end)


RegisterNUICallback('hideMouse', function(data, cb)
    SetNuiFocus(false, false)
    cb('ok')
end)

RegisterNUICallback('releaseCursor', function(data, cb)
    ReleaseCursor()
    cb('ok')
end)

RegisterNUICallback('closeInterface', function(data, cb)
    CloseInterface()
    cb('ok')
end)

RegisterNUICallback('showMouse', function(data, cb)
    if interfaceOpen then
        SetNuiFocus(true, true)
    end
    cb('ok')
end)

RegisterNUICallback('requestUpdate', function(data, cb)
    if isLoaded then
        AutoUpdateInterface()
    end
    cb('ok')
end)

RegisterNUICallback('toggleDuty', function(data, cb)
    TriggerServerEvent('QBCore:ToggleDuty')
    cb('ok')
end)

RegisterNUICallback('changeCallsign', function(data, cb)
    SetNuiFocus(false, false)

    local dialog = exports['qb-input']:ShowInput({
        header = "Change Callsign",
        submitText = "Change",
        inputs = {
            {
                text = "Callsign",
                name = "callsign",
                type = "text",
                isRequired = true,
                default = playerData.metadata and playerData.metadata.callsign or ""
            }
        }
    })

    if dialog and dialog.callsign then
        TriggerServerEvent('7MF-hub:server:changeCallsign', dialog.callsign)
    end

    -- Restore focus only if the interface is still supposed to be open
    if interfaceOpen then
        SetNuiFocus(true, true)
    end

    cb('ok')
end)

RegisterNUICallback('takeCommander', function(data, cb)
    TriggerServerEvent('7MF-hub:server:takeCommander')
    cb('ok')
end)

RegisterNUICallback('takeDispatch', function(data, cb)
    TriggerServerEvent('7MF-hub:server:takeDispatch')
    cb('ok')
end)

RegisterNUICallback('takeBreak', function(data, cb)
    TriggerServerEvent('7MF-hub:server:takeBreak')
    cb('ok')
end)


CreateThread(function()
    while true do
        Wait(0)
        if interfaceOpen and cursorActive then
            -- ESC: release cursor only — hub stays visible. F5 is the only way to close.
            if IsDisabledControlJustPressed(0, 322) then
                ReleaseCursor()
                SendNUIMessage({ type = 'police_interface', action = 'releaseCursor' })
            end
        end
    end
end)


if Config.Radio.enabled then
    CreateThread(function()
        Wait(5000)
        SetupVoiceDetection()
    end)
end


CreateThread(function()
    Wait(1000)
    SendNUIMessage({
        type = 'police_interface',
        action = 'hide'
    })
end)


CreateThread(function()
    while true do
        Wait(Config.Interface.updateInterval)

        if interfaceOpen and HasPermission() and isLoaded then
            AutoUpdateInterface()
        end
    end
end)


CreateThread(function()
    local lastOnlineCount = 0

    while true do
        Wait(10000)

        if HasPermission() and isLoaded then
            local currentOnlineCount = #GetActivePlayers()

            if currentOnlineCount ~= lastOnlineCount then
                lastOnlineCount = currentOnlineCount

                SetTimeout(2000, function()
                    AutoUpdateInterface()
                end)
            end
        end
    end
end)


AddEventHandler('onResourceStop', function(resourceName)
    if GetCurrentResourceName() == resourceName then
        if interfaceOpen then
            SetNuiFocus(false, false)
        end
    end
end)


exports('OpenInterface', OpenInterface)
exports('CloseInterface', CloseInterface)
exports('IsInterfaceOpen', function() return interfaceOpen end)
exports('UpdateInterface', AutoUpdateInterface)
exports('IsLoaded', function() return isLoaded end)


CreateThread(function()
    Wait(2000)

    if not isLoaded then
        local currentPlayerData = QBCore.Functions.GetPlayerData()

        if currentPlayerData and currentPlayerData.job then
            isLoaded = true
            playerData = currentPlayerData


            SetupVoiceDetection()
            CloseInterface()

            if HasPermission() then
                AutoUpdateInterface()
            end
        else
            CreateThread(function()
                local attempts = 0
                while not isLoaded and attempts < 10 do
                    Wait(2000)
                    attempts = attempts + 1

                    local retryPlayerData = QBCore.Functions.GetPlayerData()
                    if retryPlayerData and retryPlayerData.job then
                        isLoaded = true
                        playerData = retryPlayerData

                        SetupVoiceDetection()
                        CloseInterface()

                        if HasPermission() then
                            AutoUpdateInterface()
                        end
                        break
                    else

                    end
                end

                if not isLoaded then
                    isLoaded = true
                end
            end)
        end
    end
end)


RegisterCommand('ToggleFoucs', function()
    local currentPlayerData = QBCore.Functions.GetPlayerData()

    if not currentPlayerData or not currentPlayerData.job then
        return
    end


    local hasEmergencyJob = false
    for _, job in pairs(Config.EmergencyJobs) do
        if currentPlayerData.job.name == job then
            hasEmergencyJob = true
            break
        end
    end

    if hasEmergencyJob then
        if interfaceOpen then
            cursorActive = true
            SetNuiFocus(true, true)
        else
            QBCore.Functions.Notify('Interface must be open first', 'error')
        end
    else
        QBCore.Functions.Notify('You must be an emergency services employee', 'error')
    end
end, false)

RegisterKeyMapping('ToggleFoucs', 'Toggle Police Hub Focus', 'keyboard', "F11")


CreateThread(function()
    Wait(2000)

    if not isLoaded then
        local playerData = QBCore.Functions.GetPlayerData()

        if playerData and playerData.job then
            isLoaded = true


            SetupVoiceDetection()
            CloseInterface()

            if HasPermission() then
                AutoUpdateInterface()
            end
        else
            SetTimeout(3000, function()
                CreateThread(function()
                    local attempts = 0
                    while not isLoaded and attempts < 10 do
                        Wait(2000)
                        attempts = attempts + 1

                        local currentPlayerData = QBCore.Functions.GetPlayerData()
                        if currentPlayerData and currentPlayerData.job then
                            isLoaded = true
                            playerData = currentPlayerData

                            SetupVoiceDetection()
                            CloseInterface()

                            if HasPermission() then
                                AutoUpdateInterface()
                            end
                            break
                        else

                        end
                    end

                    if not isLoaded then
                        isLoaded = true
                    end
                end)
            end)
        end
    end
end)
AddEventHandler('playerDropped', function ()


    
end)