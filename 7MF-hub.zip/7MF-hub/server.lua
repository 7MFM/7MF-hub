-- 7MF Store https://discord.gg/3gN6ntYuke
-- ما احلل اي شخص ينشر السكربت بدون حقوقي

local QBCore = exports['qb-core']:GetCoreObject()


local function CountTableKeys(t)
    if not t then return 0 end
    local count = 0
    for _, _ in pairs(t) do
        count = count + 1
    end
    return count
end

function table.contains(table, element)
    for _, value in pairs(table) do
        if value == element then
            return true
        end
    end
    return false
end


local OnDutyPlayers = {}
local Commanders = {}
local Dispatchers = {}
local OnBreakPlayers = {}
local TalkingPlayers = {}

local GetFilteredEmployees
local GetFilteredDepartments

local function UpdateFilteredClients(job)
    if not job then return end

    local allPlayers = QBCore.Functions.GetQBPlayers()
    for src, player in pairs(allPlayers) do
        if player and player.PlayerData.job.name == job and OnDutyPlayers[src] then
            local filteredEmployees  = GetFilteredEmployees(job)
            local filteredDepartments = GetFilteredDepartments(job)
            local departmentLabel = Config.Functions and Config.Functions.GetDepartmentLabel(job)
                                    or Config.JobLabels and Config.JobLabels[job]
                                    or "Emergency Services"

            TriggerClientEvent('7MF-hub:client:updateData', src, {
                employees  = filteredEmployees,
                Employees  = filteredEmployees,
                departments = filteredDepartments,
                department  = departmentLabel
            })
        end
    end
end


local function IsEmergencyJob(job)
    for _, emergencyJob in pairs(Config.EmergencyJobs) do
        if job == emergencyJob then
            return true
        end
    end
    return false
end

local function GetPlayersByJob(job)
    local players = {}
    for src, _ in pairs(OnDutyPlayers) do
        local Player = QBCore.Functions.GetPlayer(src)
        if Player and Player.PlayerData.job.name == job then
            table.insert(players, src)
        end
    end
    return players
end

local function GetRadioPlayer(source)
    local ch = Player(source).state.radioChannel
    if type(ch) == 'number' and ch > 0 then
        return tostring(ch)
    elseif type(ch) == 'string' and ch ~= '' and ch ~= '0' then
        return ch
    end
    return 'OFF'
end

GetFilteredEmployees = function(requesterJob)
    local players = {}
    for src, _ in pairs(OnDutyPlayers) do
        local Player = QBCore.Functions.GetPlayer(src)
        if Player and Player.PlayerData.job.name == requesterJob then 
            players[src] = {
                source = src,
                callsign = Player.PlayerData.metadata.callsign or 'UNASSIGNED',
                name = Player.PlayerData.charinfo.firstname .. ' ' .. Player.PlayerData.charinfo.lastname,
                job = Player.PlayerData.job.name,
                grade = Player.PlayerData.job.grade.level or Player.PlayerData.job.grade,
                gradeName = Player.PlayerData.job.grade.name or 'Unknown',
                onDuty = OnDutyPlayers[src] or false,
                isCommander = Commanders[Player.PlayerData.job.name] == src,
                isDispatch = Dispatchers[Player.PlayerData.job.name] == src,
                onBreak = OnBreakPlayers[src] or false,
                isTalking = TalkingPlayers[src] or false,
                radio = GetRadioPlayer(src)
            }
        end
    end
    return players
end



GetFilteredDepartments = function(requesterJob)
    local departments = {}
    
    
    local jobEmployees = {}
    for src, _ in pairs(OnDutyPlayers) do
        local Player = QBCore.Functions.GetPlayer(src)
        if Player and Player.PlayerData.job.name == requesterJob then
            table.insert(jobEmployees, {
                source = src,
                callsign = Player.PlayerData.metadata.callsign or 'UNASSIGNED',
                name = Player.PlayerData.charinfo.firstname .. ' ' .. Player.PlayerData.charinfo.lastname,
                job = Player.PlayerData.job.name,
                grade = Player.PlayerData.job.grade,
                onDuty = OnDutyPlayers[src] or false,
                isCommander = Commanders[Player.PlayerData.job.name] == src,
                isDispatch = Dispatchers[Player.PlayerData.job.name] == src,
                onBreak = OnBreakPlayers[src] or false,
                isTalking = TalkingPlayers[src] or false,
                radio = GetRadioPlayer(src)
            })
        end
    end
    
    if #jobEmployees > 0 then
        local departmentLabel = Config.JobLabels[requesterJob] or "Emergency Services"
        
        table.insert(departments, {
            name = departmentLabel,
            employees = jobEmployees,
            expanded = false
        })
    end
    
    return departments
end



RegisterNetEvent('QBCore:Server:OnPlayerLoaded', function()
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    
    if not Player then 
        
        return 
    end
    
    
    
    if Player and IsEmergencyJob(Player.PlayerData.job.name) then
        
        if Player.PlayerData.job.onduty then
            OnDutyPlayers[src] = true
            
        else
            
        end
        
        
        SetTimeout(2000, function()
            UpdateFilteredClients(Player.PlayerData.job.name)
        end)
    end
end)


RegisterNetEvent('QBCore:Server:PlayerLogout', function()
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    local playerJob = Player and Player.PlayerData.job.name or nil
    
    
    
    local wasOnDuty = OnDutyPlayers[src] ~= nil
    
    
    if OnDutyPlayers[src] then
        OnDutyPlayers[src] = nil
    end
    
    if OnBreakPlayers[src] then
        OnBreakPlayers[src] = nil
    end
    
    if TalkingPlayers[src] then
        TalkingPlayers[src] = nil
    end
    
    
    for job, commanderSrc in pairs(Commanders) do
        if commanderSrc == src then
            Commanders[job] = nil
        end
    end
    
    for job, dispatchSrc in pairs(Dispatchers) do
        if dispatchSrc == src then
            Dispatchers[job] = nil
        end
    end
    
    
    if wasOnDuty and playerJob then
        SetTimeout(1000, function()
            UpdateFilteredClients(playerJob)
        end)
    end
end)


RegisterNetEvent('QBCore:Server:OnJobUpdate', function(source, job)
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    
    if not Player then return end
    
    
    
    local oldPlayerData = Player.PlayerData
    local oldJob = oldPlayerData.job and oldPlayerData.job.name or nil
    local wasInEmergencyJob = oldJob and IsEmergencyJob(oldJob) or false
    local wasOnDuty = OnDutyPlayers[src] ~= nil
    
    
    if IsEmergencyJob(job.name) and job.onduty then
        OnDutyPlayers[src] = true
        
    else
        
        if OnDutyPlayers[src] then
            OnDutyPlayers[src] = nil
            
        end
        
        if OnBreakPlayers[src] then
            OnBreakPlayers[src] = nil
        end
        
        
        for jobName, commanderSrc in pairs(Commanders) do
            if commanderSrc == src then
                Commanders[jobName] = nil
            end
        end
        
        for jobName, dispatchSrc in pairs(Dispatchers) do
            if dispatchSrc == src then
                Dispatchers[jobName] = nil
            end
        end
    end
    
    
    SetTimeout(1000, function()
        if wasInEmergencyJob and oldJob then
            UpdateFilteredClients(oldJob)
        end
        if IsEmergencyJob(job.name) then
            UpdateFilteredClients(job.name)
        end
    end)
end)


RegisterNetEvent('QBCore:Server:SetDuty', function(source, onDuty)
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    
    if not Player or not IsEmergencyJob(Player.PlayerData.job.name) then
        return
    end
    
    
    
    if onDuty then
        OnDutyPlayers[src] = true
    else
        OnDutyPlayers[src] = nil
        OnBreakPlayers[src] = nil
        
        
        local job = Player.PlayerData.job.name
        if Commanders[job] == src then
            Commanders[job] = nil
        end
        if Dispatchers[job] == src then
            Dispatchers[job] = nil
        end
    end
    
    UpdateFilteredClients(Player.PlayerData.job.name)
end)


RegisterNetEvent('7MF-hub:server:requestData', function()
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    
    if not Player then
        
        
        
        TriggerClientEvent('7MF-hub:client:receiveData', src, {
            Employees = {},
            departments = {},
            department = "Emergency Services"
        })
        return
    end
    
    if not IsEmergencyJob(Player.PlayerData.job.name) then
        
        
        
        TriggerClientEvent('7MF-hub:client:receiveData', src, {
            Employees = {},
            departments = {},
            department = "Emergency Services"
        })
        return
    end
    
    
    
    
    if Player.PlayerData.job.onduty and not OnDutyPlayers[src] then
        OnDutyPlayers[src] = true
        
    end
    
    
    local filteredEmployees = GetFilteredEmployees(Player.PlayerData.job.name)
    local filteredDepartments = GetFilteredDepartments(Player.PlayerData.job.name)
    
    
    local departmentLabel = Config.JobLabels[Player.PlayerData.job.name] or "Emergency Services"

    local responseData = {
        Employees = filteredEmployees,
        departments = filteredDepartments,
        department = departmentLabel
    }
    
    
    
    TriggerClientEvent('7MF-hub:client:receiveData', src, responseData)
end)





RegisterNetEvent('7MF-hub:server:changeCallsign', function(callsign)
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    
    if not Player or not IsEmergencyJob(Player.PlayerData.job.name) then
        return
    end
    
    if not callsign or callsign == '' then
        return
    end
    
    Player.Functions.SetMetaData('callsign', callsign)
    TriggerClientEvent('QBCore:Notify', src, Config.Notifications.callsignChanged, 'success')
    
    UpdateFilteredClients(Player.PlayerData.job.name)
end)


RegisterNetEvent('7MF-hub:server:takeCommander', function()
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    
    if not Player or not IsEmergencyJob(Player.PlayerData.job.name) or not OnDutyPlayers[src] then
        return
    end
    
    if not Config.Permissions.canTakeCommand(Player) then
        TriggerClientEvent('QBCore:Notify', src, Config.Notifications.noPermission, 'error')
        return
    end
    
    local job = Player.PlayerData.job.name
    
    if Commanders[job] and Commanders[job] ~= src then
        TriggerClientEvent('QBCore:Notify', src, Config.Notifications.alreadyCommander, 'error')
        return
    end
    
    if Commanders[job] == src then
        Commanders[job] = nil
        TriggerClientEvent('QBCore:Notify', src, Config.Notifications.commanderLeft, 'error')
    else
        Commanders[job] = src
        TriggerClientEvent('QBCore:Notify', src, Config.Notifications.commanderTaken, 'success')
    end
    
    UpdateFilteredClients(job)
end)


RegisterNetEvent('7MF-hub:server:takeDispatch', function()
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    
    if not Player or not IsEmergencyJob(Player.PlayerData.job.name) or not OnDutyPlayers[src] then
        return
    end    
    local job = Player.PlayerData.job.name
    
    if Dispatchers[job] and Dispatchers[job] ~= src then
        TriggerClientEvent('QBCore:Notify', src, Config.Notifications.alreadyDispatch, 'error')
        return
    end
    
    if Dispatchers[job] == src then
        Dispatchers[job] = nil
        TriggerClientEvent('QBCore:Notify', src, Config.Notifications.dispatchLeft, 'error')
    else
        Dispatchers[job] = src
        TriggerClientEvent('QBCore:Notify', src, Config.Notifications.dispatchTaken, 'success')
    end
    
    UpdateFilteredClients(job)
end)


RegisterNetEvent('7MF-hub:server:takeBreak', function()
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    
    if not Player or not IsEmergencyJob(Player.PlayerData.job.name) or not OnDutyPlayers[src] then
        return
    end
    
    if OnBreakPlayers[src] then
        OnBreakPlayers[src] = nil
        TriggerClientEvent('QBCore:Notify', src, Config.Notifications.offBreak, 'success')
    else
        OnBreakPlayers[src] = true
        TriggerClientEvent('QBCore:Notify', src, Config.Notifications.onBreak, 'error')
    end
    
    UpdateFilteredClients(Player.PlayerData.job.name)
end)


RegisterNetEvent('7MF-hub:server:playerTalking', function(talking)
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    
    if not Player or not IsEmergencyJob(Player.PlayerData.job.name) or not OnDutyPlayers[src] then
        return
    end
    
    if talking then
        TalkingPlayers[src] = true
    else
        TalkingPlayers[src] = nil
    end
    
    
    local allPlayers = QBCore.Functions.GetQBPlayers()
    for playerSrc, playerData in pairs(allPlayers) do
        if playerData and playerData.PlayerData.job.name == Player.PlayerData.job.name then
            TriggerClientEvent('7MF-hub:client:updateTalking', playerSrc, src, talking)
        end
    end
end)


exports('GetOnDutyPlayers', function(job)
    if job then
        return GetPlayersByJob(job)
    else
        return OnDutyPlayers
    end
end)

exports('GetCommanders', function()
    return Commanders
end)

exports('GetDispatchers', function()
    return Dispatchers
end)

exports('IsPlayerOnDuty', function(src)
    return OnDutyPlayers[src] or false
end)

exports('IsPlayerCommander', function(src)
    local Player = QBCore.Functions.GetPlayer(src)
    if not Player then return false end
    return Commanders[Player.PlayerData.job.name] == src
end)

exports('IsPlayerDispatch', function(src)
    local Player = QBCore.Functions.GetPlayer(src)
    if not Player then return false end
    return Dispatchers[Player.PlayerData.job.name] == src
end)


CreateThread(function()
    while true do
        Wait(Config.Interface.updateInterval * 5) 
        
        local jobsToUpdate = {}
        
        
        for src, _ in pairs(OnDutyPlayers) do
            local Player = QBCore.Functions.GetPlayer(src)
            if not Player then
                
                OnDutyPlayers[src] = nil
                OnBreakPlayers[src] = nil
                TalkingPlayers[src] = nil
                
                
                for job, commanderSrc in pairs(Commanders) do
                    if commanderSrc == src then
                        Commanders[job] = nil
                        jobsToUpdate[job] = true
                    end
                end
                
                for job, dispatchSrc in pairs(Dispatchers) do
                    if dispatchSrc == src then
                        Dispatchers[job] = nil
                        jobsToUpdate[job] = true
                    end
                end
                
                
            elseif not Player.PlayerData.job.onduty then
                
                OnDutyPlayers[src] = nil
                OnBreakPlayers[src] = nil
                jobsToUpdate[Player.PlayerData.job.name] = true
            end
        end
        
        
        for job, _ in pairs(jobsToUpdate) do
            UpdateFilteredClients(job)
        end
    end
end)