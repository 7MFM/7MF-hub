Config = {}


Config.Debug = true 
Config.Framework = 'qb-core'


Config.PoliceJobs = {
    'police',
    'sheriff',
    'bcso',
    'lspd',
    'marshals',
    'ranger'
}


Config.EMSJobs = {
    'ambulance',
    'doctor',
    'paramedic'
}


Config.FireJobs = {
    'fire',
    'firefighter'
}

Config.FederalJobs = {
    'fbi',
    'cia',
}


Config.EmergencyJobs = {}


for _, job in pairs(Config.PoliceJobs) do
    table.insert(Config.EmergencyJobs, job)
end


for _, job in pairs(Config.EMSJobs) do
    table.insert(Config.EmergencyJobs, job)
end


for _, job in pairs(Config.FireJobs) do
    table.insert(Config.EmergencyJobs, job)
end

for _, job in pairs(Config.FederalJobs) do
    table.insert(Config.EmergencyJobs, job)
end


Config.Interface = {
    toggleKey = 'F5', 
    closeKey = 'ESCAPE', 
    updateInterval = 2000, 
    soundVolume = 0.1,
    autoHideTime = 300000 
}


Config.Radio = {
    enabled = true, 
    scriptName = 'pma-voice', 
    talkingAnimation = true,
    talkingTimeout = 3000 
}


Config.Duty = {
    dutyLocations = {
        
        vector3(441.7989, -982.0529, 30.6896),
        
        vector3(-448.804, 6014.025, 31.7164),
        
        vector3(1835.51, 3678.93, 34.28),
        
        vector3(298.6, -584.4, 43.3),
        
        vector3(1839.6, 3672.9, 34.3)
    },
    allowRemoteDuty = true, 
    requireLocation = false 
}


Config.Ranks = {
    
    ['recruit'] = {
        label = 'Recruit',
        grade = 0,
        canTakeCommand = false,
        canTakeDispatch = false,
        jobs = Config.PoliceJobs
    },
    ['officer'] = {
        label = 'Officer',
        grade = 1,
        canTakeCommand = false,
        canTakeDispatch = true,
        jobs = Config.PoliceJobs
    },
    ['senior'] = {
        label = 'Senior Officer',
        grade = 2,
        canTakeCommand = false,
        canTakeDispatch = true,
        jobs = Config.PoliceJobs
    },
    ['corporal'] = {
        label = 'Corporal',
        grade = 3,
        canTakeCommand = true,
        canTakeDispatch = true,
        jobs = Config.PoliceJobs
    },
    ['sergeant'] = {
        label = 'Sergeant',
        grade = 4,
        canTakeCommand = true,
        canTakeDispatch = true,
        jobs = Config.PoliceJobs
    },
    ['lieutenant'] = {
        label = 'Lieutenant',
        grade = 5,
        canTakeCommand = true,
        canTakeDispatch = true,
        jobs = Config.PoliceJobs
    },
    ['captain'] = {
        label = 'Captain',
        grade = 6,
        canTakeCommand = true,
        canTakeDispatch = true,
        jobs = Config.PoliceJobs
    },
    ['chief'] = {
        label = 'Chief',
        grade = 7,
        canTakeCommand = true,
        canTakeDispatch = true,
        jobs = Config.PoliceJobs
    },
    
    
    ['trainee'] = {
        label = 'Trainee Paramedic',
        grade = 0,
        canTakeCommand = false,
        canTakeDispatch = false,
        jobs = Config.EMSJobs
    },
    ['paramedic'] = {
        label = 'Paramedic',
        grade = 1,
        canTakeCommand = false,
        canTakeDispatch = true,
        jobs = Config.EMSJobs
    },
    ['senior_paramedic'] = {
        label = 'Senior Paramedic',
        grade = 2,
        canTakeCommand = false,
        canTakeDispatch = true,
        jobs = Config.EMSJobs
    },
    ['doctor'] = {
        label = 'Doctor',
        grade = 3,
        canTakeCommand = true,
        canTakeDispatch = true,
        jobs = Config.EMSJobs
    },
    ['senior_doctor'] = {
        label = 'Senior Doctor',
        grade = 4,
        canTakeCommand = true,
        canTakeDispatch = true,
        jobs = Config.EMSJobs
    },
    ['chief_medical'] = {
        label = 'Chief of Medicine',
        grade = 5,
        canTakeCommand = true,
        canTakeDispatch = true,
        jobs = Config.EMSJobs
    }
}


Config.JobVisibility = {
    
    police = Config.PoliceJobs,
    sheriff = Config.PoliceJobs,
    bcso = Config.PoliceJobs,
    lspd = Config.PoliceJobs,
    marshals = Config.PoliceJobs,
    ranger = Config.PoliceJobs,
    
    
    ambulance = Config.EMSJobs,
    doctor = Config.EMSJobs,
    paramedic = Config.EMSJobs,
    
    
    fire = Config.FireJobs,
    firefighter = Config.FireJobs,
    fbi = {'fbi'},
    cia = {'cia'}
}


Config.JobLabels = {
    police = "Los Santos Police Department",
    sheriff = "Sheriff Department", 
    bcso = "Blaine County Sheriff's Office",
    lspd = "Los Santos Police Department",
    marshals = "US Marshals Service",
    ranger = "San Andreas Park Rangers",
    ambulance = "Emergency Medical Services",
    doctor = "Hospital Medical Staff",
    paramedic = "Emergency Medical Services",
    fire = "Los Santos Fire Department",
    firefighter = "Fire & Rescue Services",
    fbi = "Federal Bureau of Investigation",
    cia = "Central Intelligence Agency"
}


Config.Permissions = {
    canUseInterface = function(Player)
        if not Player or not Player.PlayerData then return false end
        
        local playerJob = Player.PlayerData.job.name
        for _, job in pairs(Config.EmergencyJobs) do
            if playerJob == job then
                return true
            end
        end
        return false
    end,
    
    canTakeCommand = function(Player)
        if not Player or not Player.PlayerData then return false end
        
        local grade = Player.PlayerData.job.grade.level
        local rankName = Player.PlayerData.job.grade.name
        local rank = Config.Ranks[rankName]
        
        if not rank then return false end
        
        
        local playerJob = Player.PlayerData.job.name
        local rankSupportsJob = false
        
        if rank.jobs then
            for _, supportedJob in pairs(rank.jobs) do
                if supportedJob == playerJob then
                    rankSupportsJob = true
                    break
                end
            end
        end
        
        return rankSupportsJob and rank.canTakeCommand and grade >= 3
    end,
    
    canTakeDispatch = function(Player)
        if not Player or not Player.PlayerData then return false end
        
        local grade = Player.PlayerData.job.grade.level
        local rankName = Player.PlayerData.job.grade.name
        local rank = Config.Ranks[rankName]
        
        if not rank then return false end
        
        
        local playerJob = Player.PlayerData.job.name
        local rankSupportsJob = false
        
        if rank.jobs then
            for _, supportedJob in pairs(rank.jobs) do
                if supportedJob == playerJob then
                    rankSupportsJob = true
                    break
                end
            end
        end
        
        return rankSupportsJob and rank.canTakeDispatch and grade >= 1
    end,
    
    
    canSeeEmployee = function(viewerJob, targetJob)
        if not Config.JobVisibility[viewerJob] then return false end
        
        for _, visibleJob in pairs(Config.JobVisibility[viewerJob]) do
            if visibleJob == targetJob then
                return true
            end
        end
        return false
    end
}


Config.Notifications = {
    dutyOn = 'You are now on duty',
    dutyOff = 'You are now off duty',
    commanderTaken = 'You are now the commander',
    commanderLeft = 'You are no longer the commander',
    dispatchTaken = 'You are now dispatch',
    dispatchLeft = 'You are no longer dispatch',
    onBreak = 'You are now on break',
    offBreak = 'You are no longer on break',
    callsignChanged = 'Your callsign has been changed',
    noPermission = 'You do not have permission to do this',
    alreadyCommander = 'Someone is already commander',
    alreadyDispatch = 'Someone is already dispatch',
    systemLoading = 'System is loading, please wait...',
    interfaceDisabled = 'Interface is temporarily disabled'
}


Config.Functions = {
    
    GetDepartmentLabel = function(jobName)
        return Config.JobLabels[jobName] or "Emergency Services"
    end,
    
    
    IsPoliceJob = function(jobName)
        for _, job in pairs(Config.PoliceJobs) do
            if job == jobName then return true end
        end
        return false
    end,
    
    IsEMSJob = function(jobName)
        for _, job in pairs(Config.EMSJobs) do
            if job == jobName then return true end
        end
        return false
    end,
    
    IsFireJob = function(jobName)
        for _, job in pairs(Config.FireJobs) do
            if job == jobName then return true end
        end
        return false
    end,

    IsFederalJob = function(jobName)
        for _, job in pairs(Config.FederalJobs) do
            if job == jobName then return true end
        end
        return false
    end,
    
    
    GetVisibleJobs = function(jobName)
        return Config.JobVisibility[jobName] or {jobName}
    end
}