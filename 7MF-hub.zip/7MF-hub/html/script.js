'use strict';

// ---------------------------------------------------------------------------
// Sound
// ---------------------------------------------------------------------------
const clickSound = new Audio('click_sound-D0BoMx-z.mp3');
const hoverSound = new Audio('hover_sound-B4HfdWqg.mp3');
clickSound.volume = 0.1;
hoverSound.volume = 0.07;

function playClick() { try { clickSound.currentTime = 0; clickSound.play(); } catch (_) {} }
function playHover() { try { hoverSound.currentTime = 0; hoverSound.play(); } catch (_) {} }

// ---------------------------------------------------------------------------
// State
// ---------------------------------------------------------------------------
let currentData = null;
let isVisible   = false;
let currentView = 'home';  // 'home' | 'options'

// ---------------------------------------------------------------------------
// DOM
// ---------------------------------------------------------------------------
const mainList          = document.getElementById('mainList');
const departmentLabelEl = document.getElementById('departmentLabel');
const employeeCountNum  = document.getElementById('employeeCountNumber');
const settingsIconEl    = document.getElementById('settingsIcon');
const employeesListEl   = document.getElementById('employeesList');
const homeViewEl        = document.getElementById('homeView');
const optionsViewEl     = document.getElementById('optionsView');
const employeeCountEl   = document.getElementById('employeeCount');

// ---------------------------------------------------------------------------
// Job colours — all jobs including CIA/FBI
// ---------------------------------------------------------------------------
const JOB_COLORS = {
    // Police
    police:      'rgba(52,  152, 219, 0.85)',
    lspd:        'rgba(41,  128, 185, 0.85)',
    sheriff:     'rgba(142, 68,  173, 0.85)',
    bcso:        'rgba(155, 89,  182, 0.85)',
    marshals:    'rgba(26,  82,  118, 0.85)',
    ranger:      'rgba(39,  174, 96,  0.85)',
    // EMS
    ambulance:   'rgba(231, 76,  60,  0.85)',
    doctor:      'rgba(192, 57,  43,  0.85)',
    paramedic:   'rgba(203, 67,  53,  0.85)',
    // Fire
    fire:        'rgba(230, 126, 34,  0.85)',
    firefighter: 'rgba(211, 84,  0,   0.85)',
    // Federal — same colour as police
    fbi:         'rgba(52,  152, 219, 0.85)',
    cia:         'rgba(52,  152, 219, 0.85)',
};

const COMMANDER_COLOR = 'rgba(255, 200, 0,   0.85)';
const DISPATCH_COLOR  = 'rgba(46,  204, 113, 0.85)';
const BREAK_COLOR     = 'rgba(80,  80,  80,  0.6)';

function resolveColor(emp) {
    if (emp.isCommander) return COMMANDER_COLOR;
    if (emp.isDispatch)  return DISPATCH_COLOR;
    if (emp.onBreak)     return BREAK_COLOR;
    return JOB_COLORS[emp.job] || 'rgba(100, 100, 120, 0.85)';
}

// ---------------------------------------------------------------------------
// Employee card
// ---------------------------------------------------------------------------
function createEmployeeEl(emp) {
    const card = document.createElement('div');
    card.className = 'employee'
        + (emp.isTalking ? ' talking'      : '')
        + (emp.onBreak   ? ' disableHover' : '');
    card.style.setProperty('--color', resolveColor(emp));

    const callsign = document.createElement('div');
    callsign.className = 'callsign';
    callsign.textContent = emp.callsign || 'N/A';

    const name = document.createElement('div');
    name.className = 'name';
    name.textContent = emp.name || 'Unknown';

    const rank = document.createElement('div');
    rank.className = 'rank';
    rank.textContent = emp.gradeName || '';

    const radio = document.createElement('div');
    radio.className = 'radio';
    radio.textContent = emp.radio || 'OFF';

    card.appendChild(callsign);
    card.appendChild(name);
    card.appendChild(rank);
    card.appendChild(radio);

    if      (emp.isCommander) card.appendChild(makeBadge('★ CMD', '#FFD700'));
    else if (emp.isDispatch)  card.appendChild(makeBadge('◈ DSP', '#2ECC71'));
    else if (emp.onBreak)     card.appendChild(makeBadge('⏸ BRK', '#7F8C8D'));

    if (!emp.onBreak) {
        card.addEventListener('mouseenter', () => {
            name.style.opacity = '0';
            rank.style.opacity = '1';
            playHover();
        });
        card.addEventListener('mouseleave', () => {
            name.style.opacity = '1';
            rank.style.opacity = '0';
        });
    }

    return card;
}

function makeBadge(text, color) {
    const b = document.createElement('span');
    b.style.cssText =
        `position:absolute;right:5vh;font-size:0.65vh;color:${color};font-weight:700;`;
    b.textContent = text;
    return b;
}

// ---------------------------------------------------------------------------
// Render
// ---------------------------------------------------------------------------
function sortEmployees(arr) {
    const p = e => e.isCommander ? 0 : e.isDispatch ? 1 : e.onBreak ? 3 : 2;
    return arr.slice().sort((a, b) =>
        p(a) - p(b) || (a.callsign || '').localeCompare(b.callsign || '')
    );
}

function normaliseEmployees(raw) {
    if (!raw) return [];
    return Array.isArray(raw) ? raw : Object.values(raw);
}

function renderAll(data) {
    if (!data) return;
    if (data.department) departmentLabelEl.textContent = data.department;

    const raw  = data.Employees ?? data.employees ?? {};
    const list = sortEmployees(normaliseEmployees(raw));

    employeeCountNum.textContent = list.length;
    employeesListEl.innerHTML    = '';
    list.forEach(emp => employeesListEl.appendChild(createEmployeeEl(emp)));
}

// ---------------------------------------------------------------------------
// Talking update
// ---------------------------------------------------------------------------
function handleTalkingUpdate(playerId, talking) {
    if (!currentData) return;
    const employees = currentData.Employees ?? currentData.employees;
    if (!employees) return;

    const id = String(playerId);
    if (employees[id] !== undefined) {
        employees[id].isTalking = !!talking;
    } else if (employees[playerId] !== undefined) {
        employees[playerId].isTalking = !!talking;
    } else {
        const arr = Array.isArray(employees) ? employees : Object.values(employees);
        const found = arr.find(e => String(e.source) === id);
        if (found) found.isTalking = !!talking;
    }

    if (isVisible) renderAll(currentData);
}

// ---------------------------------------------------------------------------
// Show / Hide / Update
// ---------------------------------------------------------------------------
function showInterface(data) {
    currentData = data;
    mainList.style.display = 'block';
    isVisible = true;
    switchView('home');   // reset to home only on fresh open
    renderAll(data);
}

function updateInterface(data) {
    // Called when interface is already open — keep current view, just refresh data
    currentData = data;
    renderAll(data);
}

function hideInterface() {
    mainList.style.display = 'none';
    isVisible = false;
}

// ---------------------------------------------------------------------------
// View switching
// ---------------------------------------------------------------------------
function switchView(view) {
    currentView = view;
    const goOptions = (view === 'options');

    homeViewEl.classList.toggle('active',   !goOptions);
    optionsViewEl.classList.toggle('active', goOptions);
    employeeCountEl.classList.toggle('toggled', goOptions);

    employeeCountNum.style.display = goOptions ? 'none'   : 'inline';
    settingsIconEl.style.display   = goOptions ? 'inline' : 'none';
}

// ---------------------------------------------------------------------------
// NUI callback — tries https:// then http:// (FiveM version compatibility)
// ---------------------------------------------------------------------------
const RESOURCE_NAME = (() => {
    try {
        if (typeof window.GetParentResourceName === 'function') {
            const n = window.GetParentResourceName();
            if (n && n.length > 0) return n;
        }
    } catch (_) {}
    return '7MF-hub';
})();

function sendNUI(action, data) {
    const body    = JSON.stringify(data ?? {});
    const headers = { 'Content-Type': 'application/json; charset=UTF-8' };

    // Try https:// first (default in modern FiveM)
    fetch(`https://${RESOURCE_NAME}/${action}`, { method: 'POST', headers, body })
        .catch(() => {
            // Fallback: http:// (some older FiveM builds)
            fetch(`http://${RESOURCE_NAME}/${action}`, { method: 'POST', headers, body })
                .catch(() => {});
        });
}

// ---------------------------------------------------------------------------
// Drag — hold header, move anywhere
// ---------------------------------------------------------------------------
const headerSection = mainList.querySelector('.header-section') || mainList;
headerSection.style.cursor = 'grab';

let isDragging = false;
let wasDragged = false;

headerSection.addEventListener('mousedown', e => {
    if (e.button !== 0) return;

    wasDragged = false;

    const x0 = e.clientX;
    const y0 = e.clientY;
    const l0 = parseFloat(mainList.style.left) || 0;
    const t0 = parseFloat(mainList.style.top)  || 0;

    const onMove = ev => {
        const dx = ev.clientX - x0;
        const dy = ev.clientY - y0;
        if (!isDragging && (Math.abs(dx) > 4 || Math.abs(dy) > 4)) {
            isDragging = true;
            wasDragged = true;
            headerSection.style.cursor = 'grabbing';
        }
        if (isDragging) {
            mainList.style.left = (l0 + dx) + 'px';
            mainList.style.top  = (t0 + dy) + 'px';
        }
    };

    const onUp = () => {
        isDragging = false;
        headerSection.style.cursor = 'grab';
        document.removeEventListener('mousemove', onMove);
        document.removeEventListener('mouseup',   onUp);
    };

    document.addEventListener('mousemove', onMove);
    document.addEventListener('mouseup',   onUp);
});

// ---------------------------------------------------------------------------
// Header clicks (skip if was a drag)
// ---------------------------------------------------------------------------
departmentLabelEl.addEventListener('click', () => {
    if (wasDragged) { wasDragged = false; return; }
    playClick();
    switchView('home');
});

employeeCountEl.addEventListener('click', () => {
    if (wasDragged) { wasDragged = false; return; }
    playClick();
    switchView(currentView === 'options' ? 'home' : 'options');
});

// ---------------------------------------------------------------------------
// Options buttons — stay in options after action
// ---------------------------------------------------------------------------
document.querySelectorAll('.option').forEach(opt => {
    opt.addEventListener('mouseenter', () => playHover());

    opt.addEventListener('click', () => {
        const action = opt.dataset.action;
        if (!action) return;
        playClick();

        // Visual feedback: flash orange so user sees click was registered
        opt.style.background = 'rgba(255, 117, 0, 0.35)';
        setTimeout(() => { opt.style.background = ''; }, 180);

        sendNUI(action, {});

        // changeCallsign releases NUI focus for qb-input, go home so hub doesn't block
        if (action === 'changeCallsign') {
            switchView('home');
        }
        // All other actions: stay in options
    });
});

// ---------------------------------------------------------------------------
// ESC key — capture phase
// 1st press (in options): close options → go home view
// 2nd press (in home): release cursor only — hub stays visible, F5 closes it
// ---------------------------------------------------------------------------
document.addEventListener('keydown', e => {
    const isEsc = (e.key === 'Escape' || e.keyCode === 27);
    if (!isEsc) return;

    e.preventDefault();
    e.stopPropagation();

    if (currentView === 'options') {
        // Close options, go home — cursor stays active
        switchView('home');
    } else {
        // Release cursor — hub STAYS visible, player regains character control
        sendNUI('releaseCursor', {});
        // DO NOT call hideInterface() — hub stays on screen
    }
}, true);

// ---------------------------------------------------------------------------
// NUI message listener
// ---------------------------------------------------------------------------
window.addEventListener('message', event => {
    const msg = event.data;
    if (!msg || msg.type !== 'police_interface') return;

    switch (msg.action) {

        case 'show':
            if (!isVisible) {
                // Fresh open via F5 — go to home view and render
                showInterface(msg.data);
            } else {
                // Already open (periodic update) — refresh data, keep current view
                updateInterface(msg.data);
            }
            break;

        case 'update':
        case 'forceUpdate':
            if (msg.data) {
                updateInterface(msg.data);
            }
            break;

        case 'hide':
            hideInterface();
            break;

        case 'releaseCursor':
            // Cursor released by ESC/Lua — hub stays visible, just close options if open
            if (currentView === 'options') switchView('home');
            break;

        case 'updateTalking':
            if (msg.data) handleTalkingUpdate(msg.data.playerId, msg.data.talking);
            break;
    }
});

// ---------------------------------------------------------------------------
// Init
// ---------------------------------------------------------------------------
hideInterface();
