-- 7MF Store https://discord.gg/3gN6ntYuke
-- ما احلل اي شخص ينشر السكربت بدون حقوقي
fx_version 'cerulean'
game 'gta5'

author '7MF'
description '7MF-Hub - Open Source Emergency Services Interface'
version '1.0.0'

shared_scripts {
    'config.lua'
}

client_scripts { 'client.lua' }

server_scripts { 'server.lua' }

lua54 'yes'
ui_page 'html/index.html'

files {
    'html/index.html',
    'html/styles.css',
    'html/script.js',
    'html/click_sound-D0BoMx-z.mp3',
    'html/hover_sound-B4HfdWqg.mp3',
}

-- 7MF Store https://discord.gg/3gN6ntYuke
-- ما احلل اي شخص ينشر السكربت بدون حقوقي